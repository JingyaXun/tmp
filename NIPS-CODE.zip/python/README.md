# Open Spiel Python API

This is a Python API for [Open Spiel](/third_party/open_spiel/README.md).

An example run of Pig via the Python API:

```
blaze build :example
../../../blaze-bin/third_party/open_spiel/python/example --game=pig
```
